यह frontend एक React + Vite प्रोजेक्ट का App.jsx है (single-file)।

Run locally:
1) create project: npm init vite@latest frontend -- --template react
2) copy src/App.jsx के स्थान पर इस App.jsx की सामग्री रखिए
3) npm install
4) npm run dev

Tailwind जोड़ने के लिए tailwindcss docs देखें — या simple CSS के साथ भी इस्तेमाल कर सकते हैं।